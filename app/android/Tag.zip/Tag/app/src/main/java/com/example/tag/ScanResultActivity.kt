package com.example.tag

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout.LayoutParams
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tag.models.Scan
import kotlinx.android.synthetic.main.activity_scan_result.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class ScanResultActivity : AppCompatActivity() {

    var tagId: String? = null
    var host: String? = "192.168.0.16"
    var imgPath: String? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan_result)
        setTitle(R.string.scan_result_title)

        val scanData: Scan? = intent.getParcelableExtra("scan")

        if (scanData == null) {
            Toast.makeText(
                this,
                "No information came to us, unable to show this page.",
                Toast.LENGTH_SHORT
            ).show()
            return this.finish()
        }
        tagId = scanData.uid
        textViewTagId.text ="Tag ID: " +  scanData.uid

        var thread = NetworkThread()
        thread.start()

    }

    private fun generateTextView(): TextView {
        val textView = TextView(this)

        textView.layoutParams = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.WRAP_CONTENT
        )

        return textView
    }

    private fun getStringTranslation(namespace: String, key: String): String {
        val resource: Int =
            this.resources.getIdentifier(
                String.format("scan_result_%s_%s", namespace, key),
                "string",
                packageName
            )

        return if (resource != 0) getString(resource) else "$key:"
    }

    inner class NetworkThread : Thread() {
        override fun run() {
            var site = "http://$host:28080/product/$tagId"
            var url = URL(site)
            var conn = url.openConnection()

            var input = conn.getInputStream()
            var isr = InputStreamReader(input, "UTF-8")
            var br = BufferedReader(isr)

            var str: String? = null
            var buf = StringBuffer()

            do {
                str = br.readLine()
                if (str != null) {
                    buf.append(str)
                }
            } while (str != null)

            var data = buf.toString()

            var jsonObject = JSONObject(data)


            imgPath = jsonObject.getString("photo")


            var `in`: InputStream? = null
            var bmp: Bitmap? = null
            var responseCode = -1
            try {
                val url = URL(imgPath)
                val con: HttpURLConnection = url.openConnection() as HttpURLConnection
                con.setDoInput(true)
                con.connect()
                responseCode = con.getResponseCode()
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    //download
                    `in` = con.getInputStream()
                    bmp = BitmapFactory.decodeStream(`in`)
                    `in`.close()

                }
            } catch (ex: Exception) {
                Log.e("Exception", ex.toString())
            }

            runOnUiThread {

                imageView.setImageBitmap(bmp)

                textViewModelName.text = "Model Name: " + jsonObject.getString("modelname")
                textViewBrand.text = "Brand: " + jsonObject.getString("brand")
                textViewColor.text = "Color: " + jsonObject.getString("color")
                textViewProductCode.text = "Product Code: " + jsonObject.getString("productcode")


            }
        }
    }


//    inner class NetworkThread2 : Thread() {
//        override fun run() {
//
//            var `in`: InputStream? = null
//            var bmp: Bitmap? = null
//            var responseCode = -1
//            try {
//                val url = URL(imgPath)
//                val con: HttpURLConnection = url.openConnection() as HttpURLConnection
//                con.setDoInput(true)
//                con.connect()
//                responseCode = con.getResponseCode()
//                if (responseCode == HttpURLConnection.HTTP_OK) {
//                    //download
//                    `in` = con.getInputStream()
//                    bmp = BitmapFactory.decodeStream(`in`)
//                    `in`.close()
//
//                }
//            } catch (ex: Exception) {
//                Log.e("Exception", ex.toString())
//            }
//
//            runOnUiThread {
//                imageView.setImageBitmap(bmp)
//            }
//        }
//
//    }
}