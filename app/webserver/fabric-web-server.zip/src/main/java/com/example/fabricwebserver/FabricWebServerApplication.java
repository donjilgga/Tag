package com.example.fabricwebserver;

import com.example.fabricwebserver.vo.ProductVO;
import org.example.chaincode.invocation.InitChaincode;
import org.example.chaincode.invocation.InvokeChaincode;
import org.example.chaincode.invocation.QueryChaincode;
import org.example.client.CAClient;
import org.example.client.ChannelClient;
import org.example.client.FabricClient;
import org.example.config.Config;
import org.example.user.UserContext;
import org.example.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.TransactionRequest.Type;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.nio.charset.StandardCharsets.UTF_8;

@RestController
@SpringBootApplication
public class FabricWebServerApplication extends SpringBootServletInitializer {

    private static final byte[] EXPECTED_EVENT_DATA = "!".getBytes(UTF_8);
    private static final String EXPECTED_EVENT_NAME = "event";


    public static void main(String[] args) {
        SpringApplication.run(FabricWebServerApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(FabricWebServerApplication.class);
    }

    @RequestMapping("/")
    String index() {
        return "Hello World!";
    }

    @PostMapping("/product")
    String postProduct(@RequestBody ProductVO productVO) {

        EventHub eventHub = null;

        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://" + Config.HOST + ":7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            TransactionProposalRequest request = fabClient.getInstance().newTransactionProposalRequest();
            ChaincodeID ccid = ChaincodeID.newBuilder().setName(Config.CHAINCODE_1_NAME).setVersion(Config.CHAINCODE_1_VERSION).build();
            request.setChaincodeID(ccid);
            request.setFcn("changeProduct");
            String[] arguments = {
                    productVO.getTagid(),
                    productVO.getProductcode(),
                    productVO.getModelname(),
                    productVO.getBrand(),
                    productVO.getColor(),
                    productVO.getPhoto()
            };
            request.setArgs(arguments);
            request.setProposalWaitTime(1000);

            Map<String, byte[]> tm2 = new HashMap<String, byte[]>();
            tm2.put("HyperLedgerFabric", "TransactionProposalRequest:JavaSDK".getBytes(UTF_8));
            tm2.put("method", "TransactionProposalRequest".getBytes(UTF_8));
            tm2.put("result", ":)".getBytes(UTF_8));
            tm2.put(EXPECTED_EVENT_NAME, EXPECTED_EVENT_DATA);
            request.setTransientMap(tm2);
            Collection<ProposalResponse> responses = channelClient.sendTransactionProposal(request);
            for (ProposalResponse res : responses) {
                ChaincodeResponse.Status status = res.getStatus();
                Logger.getLogger(FabricWebServerApplication.class.getName()).log(Level.INFO, "Invoked createtag on " + Config.CHAINCODE_1_NAME + ". Status - " + status);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "{\"result\" : \"postProduct FAILURE\"}";
        } finally {

            if (eventHub != null) {
                eventHub.shutdown();
            }
        }
        return "{\"result\" : \"postProduct SUCCESS\"}";
    }

    @PutMapping("/product")
    String putProduct(@RequestBody ProductVO productVO) {

        EventHub eventHub = null;
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://" + Config.HOST + ":7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            TransactionProposalRequest request = fabClient.getInstance().newTransactionProposalRequest();
            ChaincodeID ccid = ChaincodeID.newBuilder().setName(Config.CHAINCODE_1_NAME).setVersion(Config.CHAINCODE_1_VERSION).build();
            request.setChaincodeID(ccid);
            request.setFcn("createProduct");
            String[] arguments = {
                    productVO.getTagid(),
                    productVO.getProductcode(),
                    productVO.getModelname(),
                    productVO.getBrand(),
                    productVO.getColor(),
                    productVO.getPhoto()
            };
            request.setArgs(arguments);
            request.setProposalWaitTime(1000);

            Map<String, byte[]> tm2 = new HashMap<String, byte[]>();
            tm2.put("HyperLedgerFabric", "TransactionProposalRequest:JavaSDK".getBytes(UTF_8));
            tm2.put("method", "TransactionProposalRequest".getBytes(UTF_8));
            tm2.put("result", ":)".getBytes(UTF_8));
            tm2.put(EXPECTED_EVENT_NAME, EXPECTED_EVENT_DATA);
            request.setTransientMap(tm2);
            Collection<ProposalResponse> responses = channelClient.sendTransactionProposal(request);
            for (ProposalResponse res : responses) {
                ChaincodeResponse.Status status = res.getStatus();
                Logger.getLogger(InvokeChaincode.class.getName()).log(Level.INFO, "Invoked createtag on " + Config.CHAINCODE_1_NAME + ". Status - " + status);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "{\"result\" : \"putProduct FAILURE\"}";
        } finally {

            if (eventHub != null) {
                eventHub.shutdown();
            }
        }
        return "{\"result\" : \"putProduct SUCCESS\"}";
    }

    @GetMapping("/product/{tagId}")
    String getProduct(@PathVariable(value = "tagId") String tagId) {

        String stringResponse = "";

        EventHub eventHub = null;

        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://" + Config.HOST + ":7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();


            String[] args1 = {tagId};
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a product - " + args1[0]);

            Collection<ProposalResponse> responses1Query = channelClient.queryByChainCode("tag", "queryProduct", args1);

            for (ProposalResponse pres : responses1Query) {
                stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);

            }


        } catch (Exception e) {
            e.printStackTrace();
            return "{\"result\" : \"getTagId FAILURE\"}";
        } finally {

            if (eventHub != null) {
                eventHub.shutdown();
            }
        }

        return stringResponse;
    }

    @PutMapping("/enroll-user")
    String enrollUser() {
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            // Register and Enroll user to Org1MSP
            UserContext userContext = new UserContext();
            String name = "user" + System.currentTimeMillis();
            userContext.setName(name);
            userContext.setAffiliation(Config.ORG1);
            userContext.setMspId(Config.ORG1_MSP);

            String eSecret = caClient.registerUser(name, Config.ORG1);

            userContext = caClient.enrollUser(userContext, eSecret);

        } catch (Exception e) {
            e.printStackTrace();
            return "{\"result\" : \"enrollUser FAILURE\"}";
        }
        return "{\"result\" : \"enrollUser SUCCESS\"}";
    }


}


